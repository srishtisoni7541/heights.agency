# ada

This project implements WHATWG URL specification in a performant way.

The source is pulled from: https://github.com/ada-url/ada

Active development occurs in the default branch (currently named `main`).

## Updating

See [tools/dep_updaters/README.md#ada](../../tools/dep_updaters/README.md#ada)
for instructions.
